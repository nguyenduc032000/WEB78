import React from 'react'

const Statistical = () => {
  return (
    <div>Statistical</div>
  )
}

export default Statistical