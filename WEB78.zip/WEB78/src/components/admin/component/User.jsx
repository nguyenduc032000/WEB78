import React from 'react'
import NavbarAd from './NavbarAd'

const User = () => {
  return (
    <div>
        <NavbarAd/>
    </div>
  )
}

export default User